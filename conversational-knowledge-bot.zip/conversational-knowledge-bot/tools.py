# tools.py
# Simple Wikipedia search wrapper used as an external tool.
import wikipedia

wikipedia.set_lang('en')

def wiki_search(query: str, sentences: int = 3) -> str:
    """Return a short summary from Wikipedia for a query."""
    try:
        summary = wikipedia.summary(query, sentences=sentences, auto_suggest=True, redirect=True)
        return summary
    except wikipedia.DisambiguationError as e:
        options = e.options[:5]
        return f"Ambiguous query. Possible pages: {options}"
    except wikipedia.PageError:
        return "No Wikipedia page found for that query."
    except Exception as exc:
        return f"Wikipedia search error: {exc}"
