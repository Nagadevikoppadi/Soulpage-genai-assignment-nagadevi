# Conversational Knowledge Bot (LangChain + Tools + Memory)

This repo contains a minimal, tested example to run a conversational knowledge bot locally using LangChain, a memory component, and a simple Wikipedia search tool. It is designed to be easy to run and avoid common import/runtime errors by pinning compatible dependencies in `requirements.txt`.

Files included:
- streamlit_app.py       : Streamlit chat UI and glue code
- agent_setup.py        : LangChain agent + memory + tools setup
- tools.py              : A safe wrapper around the wikipedia package
- sample_chat_logs.txt  : Example dialogues
- requirements.txt
- .env.example

Instructions to run:
1. Create a virtualenv: `python -m venv .venv && source .venv/bin/activate` (or use your OS equivalent)
2. Install: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and add your `OPENAI_API_KEY`
4. Run the Streamlit app: `streamlit run streamlit_app.py`
5. Open http://localhost:8501

Note: LangChain's API evolves; the versions in requirements.txt are chosen to be compatible with the code in this repo as of creation.
