# streamlit_app.py
import streamlit as st
import os
from dotenv import load_dotenv
from agent_setup import create_agent

load_dotenv()

st.set_page_config(page_title='Conversational Knowledge Bot', layout='centered')

st.title('Conversational Knowledge Bot — LangChain + Memory + Wikipedia')

if 'agent' not in st.session_state:
    try:
        st.session_state.agent = create_agent(os.getenv('OPENAI_API_KEY'))
    except Exception as e:
        st.error(f'Error creating agent: {e}')
        st.stop()

if 'messages' not in st.session_state:
    st.session_state.messages = []

with st.form('input_form', clear_on_submit=True):
    user_input = st.text_input('You:')
    submitted = st.form_submit_button('Send')

if submitted and user_input:
    st.session_state.messages.append({'role': 'user', 'content': user_input})
    agent = st.session_state.agent
    try:
        # Use agent.run which is stable across many LangChain versions
        response = agent.run(user_input)
    except Exception as e:
        response = f'Agent error: {e}'
    st.session_state.messages.append({'role': 'assistant', 'content': response})

for msg in st.session_state.messages:
    role = msg['role']
    content = msg['content']
    if role == 'user':
        st.markdown(f"**You:** {content}")
    else:
        st.markdown(f"**Bot:** {content}")

if st.checkbox('Show internal memory (buffer)'):
    try:
        mem = st.session_state.agent.memory
        st.write(mem.load_memory_variables({}))
    except Exception as e:
        st.write(f'Memory inspection not available: {e}')
