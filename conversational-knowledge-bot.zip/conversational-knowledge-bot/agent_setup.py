# agent_setup.py
import os
from langchain import OpenAI
from langchain.memory import ConversationBufferMemory
from langchain.agents import Tool, initialize_agent, AgentType
from tools import wiki_search

def create_agent(llm_api_key: str = None):
    if llm_api_key:
        os.environ['OPENAI_API_KEY'] = llm_api_key

    # LLM - using LangChain's OpenAI wrapper (Chat completions)
    llm = OpenAI(temperature=0.0)

    # Memory - simple in-memory buffer for session (ConversationBufferMemory)
    memory = ConversationBufferMemory(memory_key='chat_history', return_messages=True)

    # Tools - register wiki_search as a Tool
    tools = [
        Tool(
            name='wiki',
            func=wiki_search,
            description='Useful for answering factual questions about people, places, events. Input should be a search query string.',
        )
    ]

    agent = initialize_agent(
        tools,
        llm,
        agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        verbose=False,
        memory=memory,
    )

    return agent
